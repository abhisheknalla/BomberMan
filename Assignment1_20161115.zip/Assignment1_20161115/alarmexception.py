from __future__ import print_function
import signal,copy,sys,time
from random import randint

class AlarmException(Exception):
    pass
